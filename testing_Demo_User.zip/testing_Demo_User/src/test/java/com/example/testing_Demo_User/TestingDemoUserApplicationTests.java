package com.example.testing_Demo_User;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestingDemoUserApplicationTests {

	@Test
	void contextLoads() {
	}

}
